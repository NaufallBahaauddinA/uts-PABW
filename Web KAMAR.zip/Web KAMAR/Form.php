<?php include 'connect.php'; ?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>KAMAR</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo-kamar.png" rel="icon">
  <link href="assets/img/logo-kamar.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================

  ======================================================== -->
</head>

<body>

  <!-- ======= Mobile nav toggle button ======= -->
  
  <i class="bi bi-list mobile-nav-toggle d-lg-none"></i>
  <!-- ======= Header ======= -->
  <header id="header" class="d-flex flex-column justify-content-center">

    <nav id="navbar" class="navbar nav-menu">
      <ul>
        <li><a href="index.html" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Utama</span></a></li>
      </ul>
    </nav><!-- .nav-menu -->

  </header><!-- End Header -->

    <div class="container">


<h1 class="mt-3 mb-3">Pendaftaran</h1>

<form action="saveform.php" method="POST">
    <!-- ID START -->
    <div class="mb-3">
        <label class="form-label">ID</label>
        <input type="text" class="form-control" name="id" placeholder="ID" required>
    </div>
    <!-- ID END -->

    <!-- NAMA START -->
    <div class="mb-3">
        <label class="form-label">Nama</label>
        <input type="text" class="form-control" name="nama" placeholder="Nama" required>
    </div>
    <!-- NAMA END -->

     <!-- Universitas START -->
     <div class="mb-3">
        <label class="form-label">Universitas</label>
        <input type="text" class="form-control" name="universitas" placeholder="Universitas" required>
    </div>
    <!-- Universitas END -->

     <!-- No telpon START -->
     <div class="mb-3">
        <label class="form-label">No Telpon</label>
        <input type="text" class="form-control" name="no_tlpn" placeholder="No Telpon" required>
    </div>
    <!-- No telpon END -->

     <!-- ALAMAT START -->
     <div class="mb-3">
        <label class="form-label">Alamat</label>
        <textarea class="form-control" name="alamat" rows="3"></textarea>
    </div>
    <!-- ALAMAT END -->

     <!-- Email START -->
     <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="text" class="form-control" name="email" placeholder="Email" required>
    </div>
    <!-- Email END -->

    <!-- SUBMIT BUTTON START -->
    <div class="mb-3">
        <input type="submit" value="Simpan" class="btn btn-sm btn-success">
    </div>
    <!-- SUBMIT BUTTON END -->
</form>


</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
</body>

</html>