<!DOCTYPE html>
<html>
<head>
	<title>Import Excel </title>
</head>
<body>
	<style type="text/css">
		body{
			font-family: sans-serif;
		}

		p{
			color: green;
		}
	</style>
	<h2>IMPORT EXCEL KAMAR</h2>

	<?php 
	if(isset($_GET['berhasil'])){
		echo "<p>".$_GET['berhasil']." Data berhasil di import.</p>";
	}
	?>

	
	<a href="upload.php"><button type="button" class="btn btn-warning">Import Data</button></a>
	<table border="1">
		<tr>
			<th>No</th>
			<th>ID</th>
			<th>Nama</th>
			<th>Universitas</th>
			<th>No Telpon</th>
			<th>Alamat</th>
			<th>Email</th>
		</tr>
		<?php 
		include 'koneksie.php';
		$no=1;
		$data = mysqli_query($koneksi,"select * from dftr");
		while($d = mysqli_fetch_array($data)){
			?>
			<tr>
				<th><?php echo $no++; ?></th>
				<th><?php echo $d['id']; ?></th>
				<th><?php echo $d['nama']; ?></th>
				<th><?php echo $d['universitas']; ?></th>
				<th><?php echo $d['no_tlpn']; ?></th>
				<th><?php echo $d['alamat']; ?></th>
				<th><?php echo $d['email']; ?></th>
			</tr>
			<?php 
		}
		?>

	</table>
</body>
</html>