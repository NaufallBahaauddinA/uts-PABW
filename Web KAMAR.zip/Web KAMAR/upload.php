<!DOCTYPE html>
<html>
<head>
	<title>Import | KAMAR</title>
</head>
<body>
	<style type="text/css">
	body{
		font-family: sans-serif;
	}

	p{
		color: green;
	}
</style>
<h2>IMPORT EXCEL KAMAR</h2>



<a href="indexx.php">Kembali</a>
<br/><br/>
<?php 
include 'koneksie.php';
?>

<form method="post" enctype="multipart/form-data" action="upload_aksi.php">
	Pilih File: 
	<input name="filepegawai" type="file" required="required"> 
	<input name="upload" type="submit" value="Import">
</form>

</body>
</html>