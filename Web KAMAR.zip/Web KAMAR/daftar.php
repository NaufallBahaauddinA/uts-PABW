<?php include 'connect.php'; ?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>KAMAR</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo-kamar.png" rel="icon">
  <link href="assets/img/logo-kamar.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================

  ======================================================== -->
</head>

<body>

  <!-- ======= Mobile nav toggle button ======= -->
  
  <i class="bi bi-list mobile-nav-toggle d-lg-none"></i>
  <!-- ======= Header ======= -->
  <header id="header" class="d-flex flex-column justify-content-center">

    <nav id="navbar" class="navbar nav-menu">
      <ul>
        <li><a href="index.html" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Utama</span></a></li>
      </ul>
    </nav><!-- .nav-menu -->

  </header><!-- End Header -->

    <!-- CONTENT SECTION START -->
    <div class="container">

<h1 class="mt-3 mb-3">Pendaftaran</h1>
        <a href="form.php" class="btn btn-sn btn-primary mb-3 mt-3">Daftar</a>
        <div class="table-responsive">
        <table class="table table-striped table-hover table-border">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Universitas</th>
                    <th>No Telpon</th>
                    <th>Alamat</th>
                    <th>Email</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = 'SELECT * FROM dftr';

                $query = mysqli_query($conn, $sql);

                while ($row = mysqli_fetch_object($query)) {
                ?>

                    <tr>
                        <td><?php echo $row->id; ?></td>
                        <td><?php echo $row->nama; ?></td>
                        <td><?php echo $row->universitas; ?></td>
                        <td><?php echo $row->no_tlpn; ?></td>
                        <td><?php echo $row->alamat; ?></td>
                        <td><?php echo $row->email; ?></td>
                        <td>
                        <div class="d-grid gap-2 d-md-block">
                        <a href='' class='btn btn-sm btn-warning'>Update</a>
                        <a href='daftar.php?$id' class='btn btn-sm btn-danger'>Delete</a>
                          
                      </div>
                       </td>
                    </tr>

                <?php
                }
                if (!mysqli_num_rows($query)) {
                    echo '<tr><td colspan="6" class="text-center">Tidak ada data.</td></tr>';
                }
                ?>
            </tbody>
        </table>
        </div>
        </div>
    <!-- CONTENT SECTION END -->

    <!-- SCRIPT SECTION START -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
    <!-- SCRIPT SECTION END -->
</body>

</html>